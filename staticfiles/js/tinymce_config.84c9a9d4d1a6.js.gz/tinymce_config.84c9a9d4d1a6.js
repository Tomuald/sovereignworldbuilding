tinymce.init({
        selector: '#textarea',
        plugins: 'link lists table',
        toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link | table',
        menubar: 'edit view insert format'
      });
