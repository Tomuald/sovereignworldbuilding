tinymce.init({
        selector: '#textarea',
        plugins: 'link, lists',
        toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link',
        menubar: 'edit view insert format'
      });
